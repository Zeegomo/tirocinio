
#define IOS_CAFFE_EXPORT __attribute__((visibility("default")))
