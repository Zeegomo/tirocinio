namespace ONNX_NAMESPACE {

const int AI_ONNX_PYTORCH_DOMAIN_MIN_OPSET = 1;
const int AI_ONNX_PYTORCH_DOMAIN_MAX_OPSET = 1;
constexpr const char* AI_ONNX_PYTORCH_DOMAIN = "ai.onnx.pytorch";

} // namespace ONNX_NAMESPACE
