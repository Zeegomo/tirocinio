#pragma once

#include <ATen/core/context_base.h>
// For CaffeMap
#include "caffe2/core/common.h"
#include "caffe2/core/logging.h"
#include "caffe2/proto/caffe2_pb.h"
