Relu, Conv, ConvRelu, ConvTranspose, AveragePool, AveragePoolRelu, MaxPool,
    MaxPoolRelu, Sum, SumRelu, Send, Receive, BatchNormalization, Clip, FC,
    GivenTensorFill, Concat, Softmax, ChannelShuffle, Add, Reshape, Flatten,
    CopyToOpenCL, CopyFromOpenCL, NCHW2NHWC, NHWC2NCHW, Declare, Export
